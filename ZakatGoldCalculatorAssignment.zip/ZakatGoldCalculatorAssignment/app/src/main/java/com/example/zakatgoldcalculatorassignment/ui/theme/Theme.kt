package com.example.zakatgoldcalculatorassignment.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// This is your existing Light Theme
private val LightColorScheme = lightColorScheme(
    primary = GoldPrimary,
    secondary = GoldSecondary,
    background = SoftBeige, // The background for light theme
    error = ErrorRed,
    surface = SurfaceColor, // e.g., for Cards
    onPrimary = Color.Black, // Text on top of primary color
    onSecondary = Color.Black, // Text on top of secondary color
    onBackground = Color.Black, // Body text color
    onSurface = Color.Black // Text on top of surfaces
)

// --- START: ADD THIS NEW DARK THEME ---
private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,       // Keep gold for primary actions
    secondary = GoldSecondary,   // Keep gold for secondary actions
    background = Color.Black,    // Here is the black background
    surface = Color(0xFF1C1C1E), // A slightly lighter black for surfaces like Cards
    error = ErrorRed,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color.White,  // Text will be white on the black background
    onSurface = Color.White      // Text on surfaces will be white
)
// --- END: NEW DARK THEME ---


@Composable
fun ZakatGoldCalculatorAssignmentTheme(
    // Parameter to detect if system is in dark mode
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Choose the correct color scheme based on the system setting
    val colorScheme = when {
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme, // Use the selected color scheme
        typography = Typography,
        content = content
    )
}
