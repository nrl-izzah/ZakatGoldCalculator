package com.example.zakatgoldcalculatorassignment.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFFFD700)
val GoldSecondary = Color(0xFFE5C100)
val SoftBackground = Color(0xFFF6F6F6)
val ErrorRed = Color(0xFFD32F2F)
val SurfaceColor = Color(0xFFFFFFFF)
val SoftBeige = Color(0xFFF8F4E3) // Example color
val VeryLightGray = Color(0xFFF7F7F7) // Another option
val PaleAqua = Color(0xFFEAF6F6) // Another option