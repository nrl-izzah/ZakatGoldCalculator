package com.example.zakatgoldcalculatorassignment

// REMOVED old imports for Intent, Uri, Toast, etc.
// ADDED LocalUriHandler for the modern way to open links
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    onNavigateBack: () -> Unit
) {
    // 1. Get the UriHandler. This is the modern way to open URLs in Compose.
    val uriHandler = LocalUriHandler.current
    // Define the URL in one place to avoid mismatches.
    val githubUrl = "https://github.com/nrl-izzah/ZakatGoldCalculator.git"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About This App") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically)
        ) {
            Text(
                text = "Zakat Gold Calculator",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "This app helps you calculate Zakat for your gold based on its weight and market price.",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Developer Details Section
            Text(text = "Developed by: Nurul 'Izzah", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Student Number: 2023637832", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Programme Code: CS251", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Group: 5A", style = MaterialTheme.typography.bodyMedium)

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Copyright © 2025 Nurul 'Izzah (CS2515A)",
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 2. UPDATED Clickable Link Section
            Text(
                text = "Application Website & Source Code:",
                style = MaterialTheme.typography.bodyMedium
            )

            ClickableText(
                // Use buildAnnotatedString for better styling and readability
                text = buildAnnotatedString {
                    withStyle(
                        style = MaterialTheme.typography.bodyMedium.toSpanStyle().copy(
                            color = MaterialTheme.colorScheme.primary,
                            textDecoration = TextDecoration.Underline,
                            fontWeight = FontWeight.Bold
                        )
                    ) {
                        // This makes the link text more user-friendly
                        append("View on GitHub")
                    }
                },
                onClick = {
                    // 3. Open the URL using the UriHandler. It's simple and safe.
                    uriHandler.openUri(githubUrl)
                }
            )
        }
    }
}

// 4. The old `openUrl` helper function is no longer needed and can be deleted.
