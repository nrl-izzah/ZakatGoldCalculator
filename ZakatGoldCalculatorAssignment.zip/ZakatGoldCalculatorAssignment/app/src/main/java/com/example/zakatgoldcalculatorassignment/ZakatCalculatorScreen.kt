package com.example.zakatgoldcalculatorassignment



import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZakatCalculatorScreen(
    onNavigateToAbout: () -> Unit
) {
    val context = LocalContext.current

    var weightInput by remember { mutableStateOf("") }
    var priceInput by remember { mutableStateOf("") }
    var goldType by remember { mutableStateOf("keep") }
    var totalValue by remember { mutableStateOf(0.0) }
    var taxableWeight by remember { mutableStateOf(0.0) }
    var zakatPayableValue by remember { mutableStateOf(0.0) }
    var zakatAmount by remember { mutableStateOf(0.0) }
    var showResult by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Zakat Gold Calculator") },
                actions = {
                    // Share button
                    IconButton(onClick = {
                        val appUrl = "https://github.com/YourGithubUsername/YourRepoName"
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "Check out this Zakat Gold Calculator app: $appUrl")
                        }
                        val shareIntent = Intent.createChooser(sendIntent, "Share app via")
                        context.startActivity(shareIntent)
                    }) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share App"
                        )
                    }

                    // About button
                    IconButton(onClick = onNavigateToAbout) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "About"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "Enter your gold information to calculate the Zakat payable.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = weightInput,
                onValueChange = { weightInput = it },
                label = { Text("Gold Weight (grams)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = priceInput,
                onValueChange = { priceInput = it },
                label = { Text("Gold Price per Gram (RM)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text("Gold Type:")
            Row {
                RadioButton(
                    selected = goldType == "keep",
                    onClick = { goldType = "keep" }
                )
                Text("Keep", modifier = Modifier.padding(end = 16.dp))

                RadioButton(
                    selected = goldType == "wear",
                    onClick = { goldType = "wear" }
                )
                Text("Wear")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = {
                        val weight = weightInput.toDoubleOrNull()
                        val price = priceInput.toDoubleOrNull()
                        val uruf = if (goldType == "keep") 85.0 else 200.0

                        if (weight != null && price != null && weight >= 0 && price >= 0) {
                            totalValue = weight * price
                            taxableWeight = (weight - uruf).coerceAtLeast(0.0)
                            zakatPayableValue = taxableWeight * price
                            zakatAmount = zakatPayableValue * 0.025
                            showResult = true
                            errorMessage = ""
                        } else {
                            errorMessage = "Please enter valid, positive numbers for weight and price."
                            showResult = false
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Calculate Zakat")
                }

                Spacer(modifier = Modifier.width(12.dp))

                Button(
                    onClick = {
                        weightInput = ""
                        priceInput = ""
                        goldType = "keep"
                        totalValue = 0.0
                        taxableWeight = 0.0
                        zakatPayableValue = 0.0
                        zakatAmount = 0.0
                        showResult = false
                        errorMessage = ""
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary
                    )
                ) {
                    Text("Reset")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (showResult) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "CALCULATION RESULTS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        InfoRow(
                            label = "Total Gold Value",
                            value = "RM %.2f".format(totalValue)
                        )
                        InfoRow(
                            label = "Taxable Gold Weight",
                            value = "%.2f g".format(taxableWeight)
                        )
                        InfoRow(
                            label = "Zakat Payable Value",
                            value = "RM %.2f".format(zakatPayableValue)
                        )
                        InfoRow(
                            label = "Total Zakat Amount (2.5%)",
                            value = "RM %.2f".format(zakatAmount)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label)
        Text(text = value, fontWeight = FontWeight.Bold)
    }
}
